<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="utf-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <!-- The above 3 meta tags *must* come first in the head; any other head content must come *after* these tags -->
        <title>Login</title>

        <!-- Bootstrap -->
        <?php include 'include/links.php' ?>
    </head>
    <body class="bg-light-gray"  onload="hide_preloader();">

        <div id="preloader">
            <div class="inner">
                <div class="spinner">
                    <div class="rect1"></div>
                    <div class="rect2"></div>
                    <div class="rect3"></div>
                    <div class="rect4"></div>
                    <div class="rect5"></div>
                </div>
            </div>
        </div>

        <main class="login-page ">
            <div class="login-wrap mx-auto">
                <div class="login-header d-flex align-items-center justify-content-center">
                  <img src="../images/logo.png" alt="logo" class="img-fluid">
                </div>
                <div class="login-field">
                    <form action="dashboard.php" autocomplete="off">
                        <div class="form-group">
                            <div class="input-group align-items-end">
                                <div class="input-group-addon"><i class="ti-email"></i> </div>
                                <input type="text" class="form-control form-control-lg" id="inlineFormInputGroup"  required/>
                                <label class="control-label">Email</label>
                            </div>
                        </div>
                        <div class="form-group">
                            <div class="input-group align-items-end">
                                <div class="input-group-addon"><i class="ti-lock"></i></div>
                                <input type="password" class="form-control form-control-lg" id="inlineFormInputGroup"  required/>
                                <label class="control-label">Password</label>
                            </div>
                        </div>
                        <div class="form-group text-center">
                            <button type="submit" class="btn btn-primary ripple-effect">LOGIN <i class="fa fa-spinner ml-1 fa-spin d-none"></i></button>
                        </div>
                    </form>
                </div>
                <div class="login-footer">
                    <a href="forgot-password.php">FORGOT PASSWORD <span class="ti-arrow-right"></span></a>
                </div>
            </div>
        </main>

        <script src="../js/jquery.min.js"></script>
        <script src="../js/popper.min.js"></script>
        <script src="../js/bootstrap.min.js"></script>
        <script type="text/javascript">
			$('.form-control').on('focus blur', function (e) {
				$(this).parents('.form-group').toggleClass('focused', (e.type === 'focus' || this.value.length > 0));
			}).trigger('blur');

            $('.ripple-effect, .ripple-effect-dark').on('click', function (e) {
            var rippleDiv = $('<span class="ripple-overlay">'),
                    rippleOffset = $(this).offset(),
                    rippleY = e.pageY - rippleOffset.top,
                    rippleX = e.pageX - rippleOffset.left;

            rippleDiv.css({
                top: rippleY - (rippleDiv.height() / 2),
                left: rippleX - (rippleDiv.width() / 2),
                // background: $(this).data("ripple-color");
            }).appendTo($(this));

            window.setTimeout(function () {
                rippleDiv.remove();
            }, 800);
        });
            var rotate = 1;

            function hide_preloader() {
                rotate = 0;
                $("#preloader").fadeOut('slow');
            }
        </script>

    </body>
</html>