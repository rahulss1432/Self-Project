@if($requests->count() > 0)
<table class="table no-border">      
    <tbody>
        @foreach($requests as $request)
        <tr>
            <td width="100" align="right">
                <div class="user_img">
                    <img src="{{getImage($request->customerDetail->profile_image,'users','users')}}" alt="user" class="rounded-circle">
                    <span class="status online"></span>
                </div>
            </td>
            <td class="min200">
                <div class="user_detail">
                    <h4>{{$request->customerDetail->contact_name}}</h4>
                    <p class="mb-0">{{$request->customerDetail->bank->name}}</p>
                </div>
            </td>
            <td class="min1100">{{$request->notes}}</td>
            <td width="200">
                <div class="user_tym">
                    <i class="icon-clock"></i> {{dateDayAgoFormat($request->created_at)}}
                </div>
            </td>
            <td width="230">Online</td>
            <td width="150"><a href="{{url('/linked-notes',$request->id)}}" class="btn btn-primary ripple-effect-dark"><i class="icon-call"></i> LINK</a></td>
        </tr>
        @endforeach
    </tbody> 
</table>
{{ $requests->links() }}
@else
<div class="alert alert-danger"><center>{{\Config::get('constants.no_record_found')}}</center></div>
@endif
<script>
    $(document).ready(function () {
        $(".pagination li a").on('click', function (e) {
            e.preventDefault();
            pageDivLoader('show', 'divCustomerRequest');
            var $this = $(this);
            var pageLink = $this.attr('href');
            $.ajax({
                type: 'GET',
                url: pageLink,
                success: function (response) {
                    $('.pagination:first').remove();
                    $("#divCustomerRequest").html(response.html);
                }
            });
        });
    });

    //ripple-effect for button
    $('.ripple-effect, .ripple-effect-dark').on('click', function (e) {
        var rippleDiv = $('<span class="ripple-overlay">'),
                rippleOffset = $(this).offset(),
                rippleY = e.pageY - rippleOffset.top,
                rippleX = e.pageX - rippleOffset.left;

        rippleDiv.css({
            top: rippleY - (rippleDiv.height() / 2),
            left: rippleX - (rippleDiv.width() / 2),
            // background: $(this).data("ripple-color");
        }).appendTo($(this));

        window.setTimeout(function () {
            rippleDiv.remove();
        }, 800);
    });
</script>