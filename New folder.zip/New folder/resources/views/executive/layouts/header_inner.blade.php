<!--header-->
<header class="header_inner fixed-top" id="top-header">
    <div class="container-fluid">
        <nav class="navbar navbar-light">
            <div class="navbar-brand">
                <a href="{{url('notification')}}" class="d-inline-block">
                    <h2 class="mb-0">LINKED ASSIST</h2>
                </a>
                <!-- <div class="toglle">
                    <div class="toggle-icon d-xl-none">
                        <i class="fa fa-bars"></i>
                    </div>
                </div> -->
            </div>
            @php
            $authUser = \Auth::guard()->user();
            @endphp
            <ul class="nav ml-auto right-utility">
                <!-- <li class="nav-item dropdown notification">
                    <a class="nav-link dropdown-toggle bell" href="#" role="button" id="notificationDrop" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                        <img src="<?php echo IMAGES_URL ?>/bell.svg">
                    </a>
                    <div class="dropdown-menu common-box" aria-labelledby="notificationDrop">
                        <div class="headline">
                            <h3 class="font-md mb-0"> Notifications</h3>
                        </div>
                        <ul class="list-unstyled">
                            <div class="scroll_notification">
                                <li>
                                    <span class="notification-icon">
                                        <i class="icon-material-outline-group"></i>
                                    </span>
                                    <span class="notification-text">
                                       You’ve made a new payment for Executive Subscription.
                                    </span>
                                </li>
                                <li>
                                    <span class="notification-icon">
                                        <i class=" icon-material-outline-gavel"></i>
                                    </span>
                                    <span class="notification-text">
                                        Your subscription is expiring on <strong>05/21/2019.</strong>
                                    </span>
                                </li>
                                <li>
                                    <span class="notification-icon">
                                        <i class="icon-material-outline-autorenew"></i>
                                    </span>
                                    <span class="notification-text">
                                        New Video Interview is submitted for <a href="javascript:void(0);">Full Stack Software Engineer.
                                        </a>
                                    </span>
                                </li>
                            </div>
                            <li class="text-center d-block view-all">
                                <a href="notification.php">VIEW ALL</a>
                            </li>
                        </ul>
                    </div>
                </li> -->
                <li class="nav-item dropdown user-avtar">
                    <a class="nav-link dropdown-toggle" href="#" role="button" id="dropdownMenuLink" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                        <img src="{{getImage($authUser->profile_image,'users','users')}}" class="rounded-circle">
                        <span class="username">{{ucfirst($authUser->contact_name)}}</span>
                    </a>
                    <div class="dropdown-menu" aria-labelledby="dropdownMenuLink">
                        <a class="dropdown-item" href="javascript:void(0);" onClick="showUserProfile()">View Profile</a>
                        <a class="dropdown-item" href="{{url('logout')}}" onclick="event.preventDefault();
                                document.getElementById('logout-form').submit();">Logout</a> 
                        <form id="logout-form" action="{{url('logout')}}" method="POST" style="display: none;">
                            {{ csrf_field() }}
                        </form>                        
                    </div>
                </li>
            </ul>
        </nav>
    </div>
</header>