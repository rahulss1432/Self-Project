<!DOCTYPE html>
<html>
    <head>
        <meta charset="utf-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no">
        <?php
        if (!defined('BASE_URL')) {
            define('BASE_URL', 'http://localhost/linkedassist-html');
            // define('BASE_URL','http://caption.neuroninc.com/neuron/linkedassist/www/');	
        }
        if (!defined('IMAGES_URL')) {
            define('IMAGES_URL', 'http://localhost/linkedassist-html/images');
            // define('IMAGES_URL','http://caption.neuroninc.com/neuron/linkedassist/www/assets/images');		
        }
        ?>
        <link rel="stylesheet" href="{{url('public/css/iocnmoon.css')}}" type="text/css">
        <link rel="stylesheet" href="{{url('public/css/bootstrap.min.css')}}" type="text/css">
        <link rel="stylesheet" href="{{url('public/css/fontawesome.min.all.css')}}" type="text/css">
        <link rel="stylesheet" href="{{url('public/css/bootstrap-select.min.css')}}" type="text/css">
        <link rel="stylesheet" href="{{url('public/css/tempusdominus-bootstrap-4.min.css')}}" type="text/css">
        <link rel="stylesheet" href="{{url('public/css/custom.min.css')}}" type="text/css">
        <link rel="stylesheet" href="{{url('public/css/toastr.min.css')}}" type="text/css">

        <!-- js script -->
        <script src="{{url('public/js/jquery.min.js')}}" type="text/javascript"></script>
        <script src="{{url('public/js/popper.min.js')}}" type="text/javascript"></script>
        <script src="{{url('public/js/bootstrap.min.js')}}" type="text/javascript"></script>
        <script src="{{url('public/js/bootstrap-select.min.js')}}" type="text/javascript"></script>
        <script src="{{url('public/js/moment.js')}}" type="text/javascript"></script>
        <script src="{{url('public/js/tempusdominus-bootstrap-4.min.js')}}" type="text/javascript"></script>
        <script src="{{url('public/js/jsvalidation.min.js')}}"></script>
        <script src="{{url('public/js/toastr.js')}}"></script>
        <title>@yield('title') | {{env('app_name')}}</title>
    </head>
    <body class="">
        @guest
        <header class="header" id="main_header">
            <nav class="navbar navbar-light pl-0 pr-0">
                <div class="container">
                    <a href="{{url('/')}}" class="navbar-brand text-uppercase font-hy">
                        linked assist
                    </a>
                </div>
            </nav>
        </header>          
        @else        
        @include('executive.layouts.header_inner')   

        @endguest
        @yield('content')
        @include('executive.layouts.footer')           
    </body>
</html>