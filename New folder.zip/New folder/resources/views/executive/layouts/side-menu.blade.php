<aside class="sidemenu">
    <div class="sidebar-wrapper">
        <div class="logo text-center">
            <img src="{{url('public/images/logo.png')}}" alt="logo" width="150">
            <a href="javascript:void(0);" class="toggle-icon d-xl-none sidemenu-icon">
                <i class="fa fa-outdent"></i>
            </a>
        </div>
        @php
        $currentRoute = Request::route()->getName();
        @endphp
        <ul id="sidemenu" class="nav flex-column sidenav" data-mcs-theme="minimal-dark">
            <li class="nav-item  {{($currentRoute == 'manager-dashboard' )?'active':''}}">
                <a class="nav-link" href="{{url('manager/dashboard')}}">
                    <i class="fa fa-dashboard"></i> Dashboard
                </a>
            </li>
            <li class="nav-item  {{($currentRoute == 'manage-merchant' || $currentRoute == 'add-merchant' || $currentRoute == 'edit-merchant' || $currentRoute == 'view-merchant'  ) ? 'active':''}}">
                <a class="nav-link" href="{{url('manager/manage-merchant')}}">
                    <i class="fa fa-users"></i> Merchants
                </a>
            </li>            
            <li class="nav-item  {{($currentRoute == 'manage-executives' || $currentRoute ==  'add-executive' ||  $currentRoute ==  'edit-executive' || $currentRoute ==  'view-executive' ) ? 'active':''}}">
                <a class="nav-link" href="{{url('manager/manage-executives')}}">
                    <i class="fa fa-user-circle-o"></i>Executives 
                </a>
            </li>
            <li class="nav-item {{($currentRoute == 'manage-document' || $currentRoute == 'add-document' || $currentRoute == 'edit-document' || $currentRoute == 'view-document') ? 'active' : ''}}">
                <a class="nav-link" href="{{url('manager/manage-document')}}">
                    <i class="fa fa-file-text-o"></i>Document
                </a> 
            </li>
            <li class="nav-item {{($currentRoute == 'manager-view-profile')?'active':''}}">
                <a class="nav-link" href="{{url('manager/view-profile')}}">
                    <i class="fa fa-user-o"></i> View Profile
                </a> 
            </li>            
            <li class="nav-item {{($currentRoute == 'manager-change-password')?'active':''}}">
                <a class="nav-link" href="{{url('manager/change-password')}}">
                    <i class="fa fa-lock"></i> Change Password
                </a> 
            </li>
        </ul>
    </div>
</aside>