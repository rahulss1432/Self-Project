@extends('executive.layouts.app')
@section('title', 'Linked Notes')
@section('content')
<main class="main-content requests-page" id="content">
    <section class="tabs_section">
        <div class="row">
            <div class="col-lg-5 col-xl-6 left">
                <ul class="list-unstyled tabs_links d-flex justify-content-start nav nav-tabs" id="myTab" role="tablist">
                    <li class="text-uppercase nav-item"><a id="note-tab" onclick="noteTab();" data-toggle="tab" href="#note" role="tab" aria-controls="note" aria-selected="true" class="nav-link active">NOTE</a></li>
                    <li class="text-uppercase nav-item"><a id="documents-tab" onclick="documentTab();" data-toggle="tab" href="#documents" role="tab" aria-controls="documents" aria-selected="false" class="nav-link">DOCUMENTS</a></li>
                    <li class="text-uppercase nav-item"><a id="history-tab" onclick="historyTab();" data-toggle="tab" href="#notesHistory" role="tab" aria-controls="notesHistory" aria-selected="false" class="nav-link">NOTES HISTORY</a></li>

                    <div class="search_box ml-auto" id="searchBox">
                        <form id="searchFilterForm" action="javascript:void(0)" onsubmit="documentTab()" method="post" autocomplete="off">
                            {{ csrf_field() }}       
                            <input type="hidden" name="bank_id" value="{{$request->customerDetail->bank->id}}">
                            <div class="input-group">
                                <input type="text" id="nameFilter" name="document_name" class="form-control" placeholder="Document name" aria-label="Document name" aria-describedby="document_button">
                                <div class="input-group-append">
                                    <button class="btn bg-transparent border-0" type="submit" id="document_button"><i class="icon-search"></i></button>
                                </div>
                            </div>
                        </form>
                    </div>
                </ul>
                <div class="tab-content tabs_content" id="myTabContent">
                    <div class="tab-pane fade show active" id="note" role="tabpanel" aria-labelledby="note-tab">
                        <div class="note_box">
                            <h5>Note</h5>
                            <p>{{$request->notes}}</p>
                        </div>
                    </div>
                    <!--document listing and view document-->
                    <div class="tab-pane fade" id="documents" role="tabpanel" aria-labelledby="documents-tab">
                        <div id="divDocumentList"></div>
                        <div class="document_view" id="viewContent">
                            <div class="d-flex justify-content-between">
                                <h4>Operation function</h4>
                                <a href="javascript:void(0);" onclick="documentClose();">Close</a>
                            </div>
                            <div class="content_text">
                                <span id="divTitle"></span>
                                <div id="divContent"></div>
                            </div>
                        </div>                        
                    </div>
                    <!-- customer and executive linked previous notes listing-->                    
                    <div class="tab-pane fade" id="notesHistory" role="tabpanel" aria-labelledby="history-tab">
                    </div>
                </div>
            </div>
            <div class="custom-col-4 col-lg-4">
                <div class="machine_sec">
                    <div class="machine_inner">
                        <img src="{{url('public/admin-manager-assets/images/machine.jpg')}}" alt="img" class="img-fluid">
                    </div>
                    <ul class="btn_list list-inline">
                        <li class="list-inline-item">
                            <div id="myEditDropdown" class="dropdown-content">
                                <a href="javascript:void(0);" class="ripple-effect-dark"><i class="icon-close"></i><span>Clear</span></a>
                                <a href="javascript:void(0);" class="ripple-effect-dark"><i class="icon-text"></i><span>Text</span></a>
                                <a href="javascript:void(0);" class="ripple-effect-dark draw"><i class="icon-highlighter"></i><span>Draw</span></a>
                                <a href="javascript:void(0);" class="ripple-effect-dark"><i class="size_text">2 pt</i><span>Size</span></a>
                                <a href="javascript:void(0);" class="ripple-effect-dark"><i class="icon-fill"></i><span>Color</span></a>
                            </div>
                            <a href="javascript:void(0);" onclick="myEditToggle()" class="icons edit_btn ripple-effect-dark"><i class="icon-edit"></i></a>
                        </li>
                        <li class="list-inline-item">
                            <a href="javascript:void(0);" onclick="openAddNoteModal();" class="icons callend_btn ripple-effect-dark"><i class="icon-call-cut"></i></a>
                        </li>
                        <li class="list-inline-item">
                            <a href="javascript:void(0);" class="icons camera_btn ripple-effect-dark"><i class="icon-photo-camera"></i></a>
                        </li>
                    </ul>
                </div>
            </div>
            <div class="custom-col-2 col-lg-3 right">
                <div class="profile_detail">
                    <img src="{{getImage($request->customerDetail->profile_image,'users','users')}}" alt="user" class="img-fluid rounded-circle">
                    <h3>{{$request->customerDetail->contact_name}}</h3>
                    <span class="bank_name">{{$request->customerDetail->bank->name}}</span>
                    <div class="info_list">
                        <div class="list d-flex justify-content-between">
                            <p>Merchant no.</p>
                            <span>{{$request->UserProfile->merchant_number}}</span>
                        </div>
                        <div class="list d-flex justify-content-between">
                            <p>Product</p>
                            <span>{{$request->UserProfile->product}}</span>
                        </div>
                        <div class="list d-flex justify-content-between">
                            <p>Company</p>
                            <span>{{$request->customerDetail->bank->name}}</span>
                        </div>
                        <div class="list d-flex justify-content-between">
                            <p>Business name</p>
                            <span>{{$request->UserProfile->bussiness_name}}</span>
                        </div>
                        <div class="list d-flex justify-content-between">
                            <p>Business address</p>
                            <span>{{$request->UserProfile->bussiness_address}}</span>
                        </div>
                        <div class="list d-flex justify-content-between">
                            <p>Mobile</p>
                            <span>{{$request->customerDetail->phone_number}}</span>
                        </div>
                        <div class="list d-flex justify-content-between">
                            <p>Email</p>
                            <span>{{$request->customerDetail->email}}</span>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
</main>
<!--call modal starts -->
<!-- add note Modal -->
<div class="modal fade common-modal add_note" id="AddNote" data-backdrop="static" tabindex="-1" role="dialog" aria-labelledby="viewHestoryModalLabel" aria-hidden="true">
    <div class="modal-dialog modal-lg modal-dialog-centered" role="document">
        <div class="modal-content">
            <div class="modal-header ">
                <div class="col text-left p-0">
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>
                <div class="col p-0 text-center">
                    <h5 class="modal-title" id="viewHestoryModalLabel">ADD NOTE</h5>
                </div>
                <div class="col p-0 text-center">

                </div>
            </div>
            <div class="modal-body" id="divAddNoteModalBody">

            </div>
        </div>
    </div>
</div>

<script>
    function status_radio(value) {
        $(".field_box").hide();
        $("." + value).show();
    }
    function notify_radio(value) {
        $(".notify_box").hide();
        $("." + value).show();
    }
    // function edit_history() {
    //     $("#EditHistory").modal("show");
    // }
</script>
<!--call modal ends -->

<script>
    function myEditToggle() {
        $("#myEditDropdown").toggleClass("active");
    }
    $(document).ready(function () {
        $('#searchBox').hide();
    });
    function openAddNoteModal() {
        $.ajax({
            type: "GET",
            url: "{{url('load-add-note-modal')}}" + '/' + '{{$request->id}}',
            success: function (response) {
                if (response.success) {
                    $("#AddNote").modal('show');
                    $('#divAddNoteModalBody').html(response.html);
                    $('.selectpicker').selectpicker('refresh');
                } else {
                    toastrAlertMessage('error', response.message);
                }
            },
            error: function (err) {
                var obj = jQuery.parseJSON(err.responseText);
                for (var x in obj) {
//                    toastrAlertMessage('error', obj[x]);
                }
            }
        });

    }
    function noteTab() {
        $('#searchBox').hide();
    }
    function documentTab() {
        $('#viewContent').hide();
        $('#divDocumentList').show();
        pageDivLoader('show', 'divDocumentList');
        var searchString = $("#searchFilterForm").serializeArray();
        $.ajax({
            type: "POST",
            url: "{{url('executive-document-list')}}",
            data: searchString,
            success: function (response) {
                if (response.success) {
                    $('#searchBox').show();
                    $('#divDocumentList').html(response.html);
                } else {
                    toastrAlertMessage('error', response.message);
                }
            },
            error: function (err) {
                var obj = jQuery.parseJSON(err.responseText);
                for (var x in obj) {
//                    toastrAlertMessage('error', obj[x]);
                }
            }
        });
    }
    function historyTab() {
        $('#searchBox').hide();
        $('#notesHistory').show();
        pageDivLoader('show', 'notesHistory');
        $.ajax({
            type: "GET",
            url: "{{url('linked-merchant-notes-history-list')}}" + '/' + '{{$request->customerDetail->id}}',
            success: function (response) {
                if (response.success) {
                    $('#notesHistory').html(response.html);
                } else {
                    toastrAlertMessage('error', response.message);
                }
            },
            error: function (err) {
                var obj = jQuery.parseJSON(err.responseText);
                for (var x in obj) {
//                    toastrAlertMessage('error', obj[x]);
                }
            }
        });
    }

    function documentView(title, content) {
        $('#viewContent').show();
        $('#divDocumentList').hide();
        $('#divTitle').html('<h6>' + title + '</h6>');
        $('#divContent').html(content);
    }

    function documentClose() {
        $('#viewContent').hide();
        $('#divDocumentList').show();
    }
</script>
@endsection