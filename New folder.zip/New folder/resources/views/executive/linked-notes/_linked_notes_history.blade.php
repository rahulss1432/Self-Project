@if($notesHistory->count() >0)
<ul class="document_list list-unstyled" id="documentList">
    @foreach($notesHistory as $note)
    <div class="document_info">
        <div class="accordion" id="accordionExample">
            <div class="card">
                <div class="card-header" id="historyheadingOne">
                    <a href="javascript:void(0);" class="bg-transparent p-0 border-0 collapsed" data-toggle="collapse" data-target="#historyOne" aria-expanded="false" aria-controls="historyOne">
                        <i class="icon-calendar"></i> {{showFullMonthDateFormat($note->created_at)}} <i class="more-less"></i>
                    </a>
                </div>

                <div id="historyOne" class="collapse" aria-labelledby="historyheadingOne" data-parent="#accordionExample">
                    <div class="card-body">
                        {!!$note->notes!!}
                    </div>
                </div>
            </div>
        </div>
    </div>
    @endforeach
</ul>
{{$notesHistory->links()}}
<script>
    $(document).ready(function () {
        $(".pagination li a").on('click', function (e) {
            e.preventDefault();
            pageDivLoader('show', 'divDocumentList');
            var $this = $(this);
            var pageLink = $this.attr('href');
            var searchString = $("#searchFilterForm").serializeArray();
            $.ajax({
                type: 'POST',
                url: pageLink,
                data: searchString,
                success: function (response) {
                    $('.pagination:first').remove();
                    $("#divDocumentList").html(response.html);
                }
            });
        });
    });

</script>

@else
<div class="alert alert-danger"><center>{{\Config::get('constants.no_record_found')}}</center></div>
@endif
