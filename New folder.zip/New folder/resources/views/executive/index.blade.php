@extends('executive.layouts.app')
@section('title', 'Login')
@section('content')
<main class="main-content login-page d-flex align-items-center">
    <div class="container">
        <div class="login_wrap">
            <div class="login-head text-center">
                <h2 class="font-bd theme-color01">SIGN IN</h2>
                <p class="mb-0">Lorem ipsum dolor sit amet, consectetur
                    <br class="d-none d-sm-block"> adipiscing elit, sed do eiusmod tempor </p>
            </div>
            <div class="login-body">
                <form class="needs-validation" id="frmLoginForm" method="POST" action="{{ url('login') }}">
                    {{ csrf_field() }}
                    <div class="form-group input_wrap">
                        <label class="control-label">Username</label>
                        <input type="text" name="username" class="form-control" placeholder="Username">
                    </div>
                    <div class="form-group input_wrap">
                        <label class="control-label">Password</label>
                        <input type="password" name="password"  class="form-control" placeholder="Enter password">
                    </div>
                    <div id="spanLoginError"></div>
                    <button type="submit" id="btnLogin" class="btn btn-primary text-uppercase ripple-effect-dark btn-block font-bk ">log in
                        <i id="loginFormLoader" class="ml-1 fa-spin fas fa-spinner" style="display: none"></i>
                    </button>
                </form>
                {!! JsValidator::formRequest('App\Http\Requests\Executive\ExecutiveLoginRequest','#frmLoginForm') !!}                        
            </div>
        </div>
    </div>
</main>
<script>
    $(document).on('submit', '#frmLoginForm', function (e) {
        $('#spanLoginError').text('');
        e.preventDefault();
        if ($('#frmLoginForm').valid()) {
            $('#btnLogin').prop('disabled', true);
            $('#loginFormLoader').show();
            $.ajax({
                url: "{{ url('login') }}",
                data: $('#frmLoginForm').serialize(),
                type: 'POST',
                dataType: 'JSON',
                success: function (response) {
                    if (response.success) {
                        toastrAlertMessage('success', response.message);
                        setTimeout(function () {
                            window.location = response.redirectUrl;
                        }, 1500);
                    } else {
                        toastrAlertMessage('error', response.message);
                        $('#btnLogin').prop('disabled', false);
                        $('#loginFormLoader').hide();
                    }
                },
                error: function (err) {
                    var obj = jQuery.parseJSON(err.responseText);
                    for (var x in obj) {
                        $('#loginFormLoader').hide();
                        $('#btnLogin').prop('disabled', false);
                        $('#spanLoginError').html('<span class="help-block error-help-block">' + obj[x] + '</span>');
                    }
                }
            });
        }
    });
</script>        
@endsection