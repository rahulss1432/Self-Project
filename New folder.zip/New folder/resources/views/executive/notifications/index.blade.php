@extends('executive.layouts.app')
@section('title', 'Notification')
@section('content')
@php
$currentRoute = Request::route()->getName();
@endphp
<main class="main-content requests-page" id="content">
    <section class="tabs_section">
        <ul class="list-unstyled tabs_links d-flex justify-content-start">
            <li class="text-uppercase {{($currentRoute == 'executive-notification' )?'active':''}}"><a href="{{url('notification')}}">NOTIFICATIONS <span>(05)</span></a></li>
            <li class="text-uppercase {{($currentRoute == 'executive-request' )?'active':''}}"><a href="{{url('customer-request')}}">CUSTOMER REQUESTS</a></li>
            <li class="text-uppercase {{($currentRoute == 'executive-history' )?'active':''}}"><a href="{{url('linked-history')}}">LINKED HISTORY</a></li>
        </ul>
        <div class="tabs_content">
            <div class="table-responsive">
                <table class="table no-border">
                    <tbody id="getnotifications"></tbody>
                </table>
            </div>
        </div>
    </section>
</main>
<script>
    $(document).ready(function () {
        getNotificationslist();
    });
    function getNotificationslist() {
        $("#getnotifications").html('<div class="listloader text-center pb-4"><i class="fa-2x fa-spin fas fa-spinner"></i></div>');
        var url = '{{url("notification-list")}}';
        $.ajax({type: "GET", url: url,
            success: function (response) {
                setTimeout(function () {
                    $("#getnotifications").html("");
                    $("#getnotifications").hide().html(response.html).fadeIn('2000');
                }, 1000);
            }
        });
    }
</script>
@endsection