<tr>
    <td align="right">
        <div class="user_img">
            <img src="{{asset('public/')}}/assets/images/user01.jpg" alt="user" class="rounded-circle">
        </div>
    </td>
    <td class="min200">
        <div class="user_detail">
            <h4>Micah Chan</h4>
            <p class="mb-0">American Express Bank</p>
        </div>
    </td>
    <td class="min1100">Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut ero labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco poriti laboris nisi ut aliquip ex ea commodo consequat.</td>
    <td width="200">
        <div class="user_tym">
            <i class="icon-clock"></i>3:16 PM
        </div>
    </td>
    <td><a href="{{url('/linked-notes')}}" class="btn btn-primary ripple-effect-dark"><i class="icon-call"></i> LINK</a></td>
</tr>
<tr>
    <td align="right">
        <div class="user_img">
            <img src="{{asset('public/')}}/assets/images/user02.jpg" alt="user" class="rounded-circle">
        </div>
    </td>
    <td class="min200">
        <div class="user_detail">
            <h4>Kendall Campos</h4>
            <p class="mb-0">American Express Bank</p>
        </div>
    </td>
    <td class="min1100">Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut ero labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco poriti laboris nisi ut aliquip ex ea commodo consequat.</td>
    <td width="200">
        <div class="user_tym">
            <i class="icon-clock"></i>2:10 PM
        </div>
    </td>
    <td><a href="{{url('/linked-notes')}}" class="btn btn-primary ripple-effect-dark"><i class="icon-call"></i> LINK</a></td>
</tr>
<tr>
    <td align="right">
        <div class="user_img">
            <img src="{{asset('public/')}}/assets/images/user03.jpg" alt="user" class="rounded-circle">
        </div>
    </td>
    <td class="min200">
        <div class="user_detail">
            <h4>Clementine Fischer</h4>
            <p class="mb-0">American Express Bank</p>
        </div>
    </td>
    <td class="min1100">Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut ero labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco poriti laboris nisi ut aliquip ex ea commodo consequat.</td>
    <td>
        <div class="user_tym">
            <i class="icon-clock"></i>1:02 PM
        </div>
    </td>
    <td></td>
</tr>
<tr>
    <td align="right">
        <div class="user_img">
            <img src="{{asset('public/')}}/assets/images/user04.jpg" alt="user" class="rounded-circle">
        </div>
    </td>
    <td class="min200">
        <div class="user_detail">
            <h4>Elmo Pratt</h4>
            <p class="mb-0">American Express Bank</p>
        </div>
    </td>
    <td class="min1100">Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut ero labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco poriti laboris nisi ut aliquip ex ea commodo consequat.</td>
    <td>
        <div class="user_tym">
            <i class="icon-clock"></i>4:12 PM
        </div>
    </td>
    <td></td>
</tr>
<tr>
    <td align="right">
        <div class="user_img">
            <img src="{{asset('public/')}}/assets/images/user05.jpg" alt="user" class="rounded-circle">
        </div>
    </td>
    <td class="min200">
        <div class="user_detail">
            <h4>Marny Sampson</h4>
            <p class="mb-0">American Express Bank</p>
        </div>
    </td>
    <td class="min1100">Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut ero labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco poriti laboris nisi ut aliquip ex ea commodo consequat.</td>
    <td>
        <div class="user_tym">
            <i class="icon-clock"></i>1:11 PM
        </div>
    </td>
    <td></td>
</tr>
<tr>
    <td align="right">
        <div class="user_img">
            <img src="{{asset('public/')}}/assets/images/user06.jpg" alt="user" class="rounded-circle">
        </div>
    </td>
    <td class="min200">
        <div class="user_detail">
            <h4>Dalton Hoover</h4>
            <p class="mb-0">American Express Bank</p>
        </div>
    </td>
    <td class="min1100">Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut ero labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco poriti laboris nisi ut aliquip ex ea commodo consequat.</td>
    <td width="200">
        <div class="user_tym">
            <i class="icon-clock"></i>1:11 PM
        </div>
    </td>
    <td></td>
</tr>
<tr>
    <td align="right">
        <div class="user_img">
            <img src="{{asset('public/')}}/assets/images/user07.jpg" alt="user" class="rounded-circle">
        </div>
    </td>
    <td class="min200">
        <div class="user_detail">
            <h4>Steven Bray</h4>
            <p class="mb-0">American Express Bank</p>
        </div>
    </td>
    <td class="min1100">Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut ero labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco poriti laboris nisi ut aliquip ex ea commodo consequat.</td>
    <td width="200">
        <div class="user_tym">
            <i class="icon-clock"></i>1:11 PM
        </div>
    </td>
    <td></td>
</tr>
<tr>
    <td align="right">
        <div class="user_img">
            <img src="{{asset('public/')}}/assets/images/user08.jpg" alt="user" class="rounded-circle">
        </div>
    </td>
    <td class="min200">
        <div class="user_detail">
            <h4>Genevieve Stark</h4>
            <p class="mb-0">American Express Bank</p>
        </div>
    </td>
    <td class="min1100">Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut ero labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco poriti laboris nisi ut aliquip ex ea commodo consequat.</td>
    <td width="200">
        <div class="user_tym">
            <i class="icon-clock"></i>1:11 PM
        </div>
    </td>
    <td></td>
</tr>

<script>
    //ripple-effect for button
    $('.ripple-effect, .ripple-effect-dark').on('click', function (e) {
        var rippleDiv = $('<span class="ripple-overlay">'),
                rippleOffset = $(this).offset(),
                rippleY = e.pageY - rippleOffset.top,
                rippleX = e.pageX - rippleOffset.left;

        rippleDiv.css({
            top: rippleY - (rippleDiv.height() / 2),
            left: rippleX - (rippleDiv.width() / 2),
            // background: $(this).data("ripple-color");
        }).appendTo($(this));

        window.setTimeout(function () {
            rippleDiv.remove();
        }, 800);
    });
</script>