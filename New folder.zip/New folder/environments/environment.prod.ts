export const environment = {
  production: true,
  baseUrl: 'http://heybaby-newapi.codiant.com/api/'
};
